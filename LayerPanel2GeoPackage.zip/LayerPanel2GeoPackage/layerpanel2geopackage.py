# -*- coding: utf-8 -*-
"""LayerPanel2GeoPackage QGIS plugin.

Exports vector layers in the layer panel to a single GeoPackage and raster
layers to a sibling folder as GeoTIFF. Output names are based on layer names
with CRS/EPSG suffixes.
"""

import copy
import os
import re
import tempfile
import traceback
import zipfile
from xml.dom import minidom

from qgis.PyQt.QtCore import QCoreApplication, QEventLoop, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QProgressDialog,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QVBoxLayout,
)

from qgis.core import (
    QgsFeedback,
    QgsMapLayer,
    QgsMapLayerStyle,
    QgsProject,
    QgsRasterBlockFeedback,
    QgsRasterFileWriter,
    QgsRasterPipe,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

try:
    from qgis.core import QgsLayerTreeLayer
except Exception:  # pragma: no cover - QGIS provides this in normal use
    QgsLayerTreeLayer = None


PLUGIN_NAME = "LayerPanel2GeoPackage"
PLUGIN_VERSION = "0.1.4"
INVALID_NAME_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_output_name(name, fallback="layer"):
    """Return a safe output layer/file base name while keeping Japanese text."""
    text = str(name or "").strip()
    text = INVALID_NAME_RE.sub("_", text)
    text = re.sub(r"\s+", " ", text).strip()
    # Windows does not like trailing dots/spaces in file names. Keep spaces inside.
    text = text.rstrip(". ")
    if not text:
        text = fallback
    return text


def crs_suffix(layer):
    """Return EPSG code suffix where possible, otherwise a safe CRS suffix."""
    try:
        crs = layer.crs()
        if crs and crs.isValid():
            authid = crs.authid() or ""
            if authid.upper().startswith("EPSG:"):
                code = authid.split(":", 1)[1]
                return sanitize_output_name(code, "noCRS")
            if authid:
                return sanitize_output_name(authid.replace(":", "_"), "noCRS")
    except Exception:
        pass
    return "noCRS"


def layer_type_name(layer):
    if layer.type() == QgsMapLayer.VectorLayer:
        return "ベクタ"
    if layer.type() == QgsMapLayer.RasterLayer:
        return "ラスタ"
    return "対象外"


def is_vector_layer(layer):
    return layer and layer.isValid() and layer.type() == QgsMapLayer.VectorLayer


def is_gdal_raster_layer(layer):
    if not layer or not layer.isValid() or layer.type() != QgsMapLayer.RasterLayer:
        return False
    try:
        return (layer.providerType() or "").lower() == "gdal"
    except Exception:
        return False


def make_unique_directory(base_dir):
    """Create and return a new unique directory path."""
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
        return base_dir
    index = 2
    while True:
        candidate = f"{base_dir}_{index}"
        if not os.path.exists(candidate):
            os.makedirs(candidate)
            return candidate
        index += 1


def vector_writer_error_message(result):
    """Normalize PyQGIS writer return values across QGIS 3 versions."""
    if isinstance(result, tuple):
        err = result[0]
        msg_parts = []
        for part in result[1:]:
            if isinstance(part, str) and part:
                msg_parts.append(part)
        return err, " / ".join(msg_parts)
    return result, ""


def is_no_error(error_code):
    try:
        return int(error_code) == int(QgsVectorFileWriter.NoError)
    except Exception:
        return error_code == QgsVectorFileWriter.NoError


def prepare_gpkg_fid_attributes(layer, options):
    """Preserve input 'fid' values under a non-PK name during GPKG export.

    GeoPackage reserves 'fid' for an integer primary key. Processing tools may
    leave the input fid attribute duplicated (e.g. after splitting polygons).
    Mapping it to source_fid allows SQLite/GDAL to generate new unique fid
    values WITHOUT modifying the source layer, loading it in memory a second
    time, or discarding any of its attributes.

    Returns the renamed output field, or None when no input fid exists.
    """
    field_names = [field.name() for field in layer.fields()]
    fid_indices = [i for i, name in enumerate(field_names) if name.casefold() == "fid"]
    if not fid_indices:
        return None

    used_names = {name.casefold() for name in field_names}
    output_names = list(field_names)
    remapped = []
    for index in fid_indices:
        candidate = "source_fid"
        number = 2
        while candidate.casefold() in used_names:
            candidate = f"source_fid_{number}"
            number += 1
        used_names.add(candidate.casefold())
        output_names[index] = candidate
        remapped.append(candidate)

    # QGIS SaveVectorOptions maps export names by ORIGINAL field index.
    # Explicitly enumerate every field so no non-fid attributes are dropped.
    options.attributes = list(range(len(field_names)))
    options.attributesExportNames = output_names
    return remapped[0] if len(remapped) == 1 else ", ".join(remapped)


def verify_vector_output(source_layer, gpkg_path, target_name, expected_count, preserved_fid_name):
    """Never treat a partial vector write as a successful, reusable export."""
    uri = f"{gpkg_path}|layername={target_name}"
    exported = QgsVectorLayer(uri, target_name, "ogr")
    if not exported.isValid():
        return False, "出力したGeoPackageレイヤを読み込めません"

    count = exported.featureCount()
    if expected_count >= 0 and count != expected_count:
        return False, f"地物数が一致しません（元: {expected_count} 件 / 出力: {count} 件）"

    if preserved_fid_name:
        output_fields = {field.name().casefold() for field in exported.fields()}
        # Always generated by the GeoPackage driver; source_fid stores source IDs.
        for name in preserved_fid_name.split(", "):
            if name.casefold() not in output_fields:
                return False, f"元fidの保存先属性 {name} が見つかりません"
    return True, ""


class ExportSettingsDialog(QDialog):
    """Main settings dialog."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{PLUGIN_NAME} - v{PLUGIN_VERSION}")
        self.resize(640, 290)

        self.path_edit = QLineEdit(self)
        self.path_edit.setPlaceholderText("例：D:/work/output.gpkg")
        browse_button = QPushButton("参照...", self)
        browse_button.clicked.connect(self.browse_gpkg)

        path_layout = QHBoxLayout()
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(browse_button)

        self.vector_check = QCheckBox("ベクタレイヤをGeoPackageに保存", self)
        self.vector_check.setChecked(True)
        self.vector_style_check = QCheckBox("ベクタスタイルをGeoPackage内に保存", self)
        self.vector_style_check.setChecked(True)
        self.raster_check = QCheckBox("ラスタレイヤを同階層の新規フォルダにGeoTIFF保存", self)
        self.raster_check.setChecked(True)
        self.raster_style_check = QCheckBox("ラスタスタイルを.qmlとして保存", self)
        self.raster_style_check.setChecked(True)
        self.project_check = QCheckBox("QGISプロジェクトファイル（.qgz）を新規保存（出力データを参照）", self)
        self.project_check.setChecked(True)

        option_box = QGroupBox("保存内容", self)
        option_layout = QVBoxLayout(option_box)
        option_layout.addWidget(self.vector_check)
        option_layout.addWidget(self.vector_style_check)
        option_layout.addWidget(self.raster_check)
        option_layout.addWidget(self.raster_style_check)
        option_layout.addWidget(self.project_check)

        note = QLabel(
            "保存名は、レイヤ名の末尾に _EPSGコード を付けます。\n"
            "例：建物 → 建物_6668、DEM → DEM_6668.tif\n"
            "重複する保存名がある場合は、実行前に編集ウィンドウを表示します。",
            self,
        )
        note.setWordWrap(True)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        buttons.button(QDialogButtonBox.Ok).setText("実行")
        buttons.button(QDialogButtonBox.Cancel).setText("キャンセル")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.addRow("出力先GeoPackage：", path_layout)
        layout.addLayout(form)
        layout.addWidget(option_box)
        layout.addWidget(note)
        layout.addStretch(1)
        layout.addWidget(buttons)

        self.vector_check.toggled.connect(self.vector_style_check.setEnabled)
        self.raster_check.toggled.connect(self.raster_style_check.setEnabled)

    def browse_gpkg(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "出力先GeoPackageを選択",
            "",
            "GeoPackage (*.gpkg)",
        )
        if path:
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            self.path_edit.setText(path)

    def settings(self):
        return {
            "gpkg_path": self.path_edit.text().strip(),
            "save_vectors": self.vector_check.isChecked(),
            "save_vector_styles": self.vector_style_check.isChecked(),
            "save_rasters": self.raster_check.isChecked(),
            "save_raster_styles": self.raster_style_check.isChecked(),
            "save_project": self.project_check.isChecked(),
        }

    def accept(self):
        path = self.path_edit.text().strip()
        if not path:
            QMessageBox.warning(self, PLUGIN_NAME, "出力先GeoPackageを指定してください。")
            return
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
            self.path_edit.setText(path)
        parent_dir = os.path.dirname(path)
        if not parent_dir:
            QMessageBox.warning(self, PLUGIN_NAME, "保存先フォルダを含むパスを指定してください。")
            return
        if not os.path.isdir(parent_dir):
            QMessageBox.warning(self, PLUGIN_NAME, "保存先フォルダが存在しません。")
            return
        if not self.vector_check.isChecked() and not self.raster_check.isChecked():
            QMessageBox.warning(self, PLUGIN_NAME, "保存対象を1つ以上選択してください。")
            return
        super().accept()


class NameEditDialog(QDialog):
    """Dialog shown when duplicate output names need user confirmation/editing."""

    def __init__(self, entries, parent=None):
        super().__init__(parent)
        self.entries = entries
        self.setWindowTitle("保存名の確認・編集")
        self.resize(820, 420)

        label = QLabel(
            "重複する保存名があるため、自動で _2, _3... を付けました。\n"
            "必要に応じて、保存先名を編集してください。",
            self,
        )
        label.setWordWrap(True)

        self.table = QTableWidget(self)
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["種別", "元レイヤ名", "CRS", "保存先名"])
        self.table.setRowCount(len(entries))
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setAlternatingRowColors(True)

        for row, entry in enumerate(entries):
            type_item = QTableWidgetItem("ベクタ" if entry["kind"] == "vector" else "ラスタ")
            source_item = QTableWidgetItem(entry["source_name"])
            crs_item = QTableWidgetItem(entry["crs_label"])
            target_item = QTableWidgetItem(entry["target_name"])
            for item in (type_item, source_item, crs_item):
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            if entry.get("auto_renamed"):
                target_item.setToolTip("重複回避のため自動変更されています。")
            self.table.setItem(row, 0, type_item)
            self.table.setItem(row, 1, source_item)
            self.table.setItem(row, 2, crs_item)
            self.table.setItem(row, 3, target_item)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.Stretch)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        buttons.button(QDialogButtonBox.Ok).setText("この名前で保存")
        buttons.button(QDialogButtonBox.Cancel).setText("キャンセル")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(label)
        layout.addWidget(self.table, 1)
        layout.addWidget(buttons)

    def accept(self):
        seen = {}
        cleaned_names = []
        for row, entry in enumerate(self.entries):
            item = self.table.item(row, 3)
            name = sanitize_output_name(item.text() if item else "", f"layer_{row + 1}")
            if not name:
                QMessageBox.warning(self, PLUGIN_NAME, "保存先名が空の行があります。")
                return
            key = (entry["kind"], name.casefold())
            if key in seen:
                first = seen[key] + 1
                QMessageBox.warning(
                    self,
                    PLUGIN_NAME,
                    f"保存先名が重複しています。\n\n{first}行目 と {row + 1}行目：{name}",
                )
                return
            seen[key] = row
            cleaned_names.append(name)

        for row, name in enumerate(cleaned_names):
            self.entries[row]["target_name"] = name
        super().accept()


class LogDialog(QDialog):
    """Scrollable export result dialog."""

    def __init__(self, title, text, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(780, 520)
        edit = QTextEdit(self)
        edit.setReadOnly(True)
        edit.setPlainText(text)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok, self)
        buttons.button(QDialogButtonBox.Ok).setText("閉じる")
        buttons.accepted.connect(self.accept)
        layout = QVBoxLayout(self)
        layout.addWidget(edit, 1)
        layout.addWidget(buttons)



class ExportProgressDialog:
    """Visible, non-cancelable progress during synchronous QGIS exports.

    Each save/style/rebind/project task occupies a step. If the QGIS provider
    emits a real progress percentage, display it inside the active step; if it
    doesn't, the dialog still displays the active layer and completed steps.
    """

    def __init__(self, total_steps, parent):
        self.total_steps = max(1, total_steps)
        self.completed = 0
        self.last_percent = -1
        self.dialog = QProgressDialog("保存処理を準備しています…", "", 0, self.total_steps * 100, parent)
        self.dialog.setWindowTitle(f"{PLUGIN_NAME} - v{PLUGIN_VERSION} / 保存中")
        self.dialog.setWindowModality(Qt.ApplicationModal)
        self.dialog.setCancelButton(None)  # Cancellation during a write can leave partial GPKG data.
        self.dialog.setMinimumDuration(0)
        self.dialog.setAutoClose(False)
        self.dialog.setAutoReset(False)
        self.dialog.setMinimumWidth(560)
        self.dialog.setValue(0)
        self.dialog.show()
        self._refresh()

    @staticmethod
    def _refresh():
        # Keep the dialog painted without permitting mouse/key actions which
        # could alter layer tree or source layers while QGIS is writing them.
        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

    def start(self, task, name=""):
        self.last_percent = -1
        detail = f"：{name}" if name else ""
        self.dialog.setLabelText(
            f"{task}{detail}\n"
            f"処理 {self.completed + 1} / {self.total_steps}（レイヤ内の進捗が取得できない場合もあります）"
        )
        self.dialog.setValue(self.completed * 100)
        self._refresh()

    def update_percent(self, percent):
        try:
            number = max(0, min(99, int(float(percent))))
        except (TypeError, ValueError):
            return
        if number == self.last_percent:
            return
        self.last_percent = number
        self.dialog.setValue(self.completed * 100 + number)
        self._refresh()

    def finish(self):
        self.completed = min(self.total_steps, self.completed + 1)
        self.dialog.setValue(self.completed * 100)
        self._refresh()

    def close(self):
        self.dialog.close()


class ProjectSaveError(RuntimeError):
    """A project-save failure with an actionable stage description."""


def _direct_child(element, name):
    return next(
        (node for node in element.childNodes if node.nodeType == node.ELEMENT_NODE and node.tagName == name),
        None,
    )


def _element_text(element):
    return "".join(
        node.data for node in element.childNodes
        if node.nodeType in (node.TEXT_NODE, node.CDATA_SECTION_NODE)
    )


def _set_element_text(element, doc, value):
    for child in list(element.childNodes):
        element.removeChild(child)
    element.appendChild(doc.createTextNode(value))


def rewrite_qgs_xml(xml_bytes, data_sources):
    """Rewrite data providers and sources in a complete, serialized .qgs XML.

    Returns (bytes, set of written layer IDs). This is independent of any
    QGIS live signals and can be unit-tested without a QGIS installation.
    """
    try:
        document = minidom.parseString(xml_bytes)
    except Exception as exc:
        raise ProjectSaveError(f"QGISプロジェクトXMLを読み込めません: {exc}") from exc

    changed = set()
    for element in document.getElementsByTagName("maplayer"):
        id_element = _direct_child(element, "id")
        if id_element is None:
            continue
        layer_id = _element_text(id_element)
        if layer_id not in data_sources:
            continue
        source_element = _direct_child(element, "datasource")
        provider_element = _direct_child(element, "provider")
        if source_element is None or provider_element is None:
            raise ProjectSaveError(f"レイヤID {layer_id} のdatasource/provider情報が見つかりません")
        provider, source = data_sources[layer_id]
        _set_element_text(source_element, document, source)
        _set_element_text(provider_element, document, provider)
        changed.add(layer_id)

    missing = set(data_sources) - changed
    if missing:
        raise ProjectSaveError(f"保存したプロジェクト内に出力レイヤIDがありません（{len(missing)}件）: {', '.join(sorted(missing)[:4])}")

    for node in document.getElementsByTagName("layer-tree-layer"):
        layer_id = node.getAttribute("id")
        if layer_id in data_sources:
            provider, source = data_sources[layer_id]
            node.setAttribute("source", source)
            node.setAttribute("providerKey", provider)

    return document.toxml(encoding="UTF-8"), changed


def check_qgs_xml_sources(xml_bytes, data_sources):
    """Verify the data sources in the finished QGIS project archive."""
    try:
        document = minidom.parseString(xml_bytes)
    except Exception as exc:
        raise ProjectSaveError(f"完成したQGISプロジェクトXMLが破損しています: {exc}") from exc

    found = {}
    for element in document.getElementsByTagName("maplayer"):
        identifier = _direct_child(element, "id")
        if identifier is None:
            continue
        layer_id = _element_text(identifier)
        if layer_id not in data_sources:
            continue
        source = _direct_child(element, "datasource")
        provider = _direct_child(element, "provider")
        if source is None or provider is None:
            raise ProjectSaveError(f"レイヤID {layer_id} の保存先情報が欠落しました")
        found[layer_id] = (_element_text(provider), _element_text(source))

    mismatched = [layer_id for layer_id, expected in data_sources.items() if found.get(layer_id) != expected]
    if mismatched:
        raise ProjectSaveError(f"出力データの参照先検証に失敗しました（{len(mismatched)}件）: {', '.join(mismatched[:4])}")


class LayerPanel2GeoPackage:
    """Main plugin class."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.toolbar = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path), PLUGIN_NAME, self.iface.mainWindow())
        self.action.setObjectName("LayerPanel2GeoPackageAction")
        self.action.setToolTip("レイヤパネル上のレイヤをGeoPackageへ一括保存")
        self.action.triggered.connect(self.run)

        # layer2shp と同じ「拡張機能」共通ツールバーへ追加する。
        toolbar_name = "拡張機能"
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, toolbar_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(toolbar_name)
            self.toolbar.setObjectName(toolbar_name)
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

        self.iface.addPluginToMenu(PLUGIN_NAME, self.action)

    def unload(self):
        if self.action is not None:
            if self.toolbar is not None:
                self.toolbar.removeAction(self.action)
            self.iface.removePluginMenu(PLUGIN_NAME, self.action)
            self.action = None
        self.toolbar = None

    def run(self):
        dialog = ExportSettingsDialog(self.iface.mainWindow())
        if dialog.exec_() != QDialog.Accepted:
            return
        settings = dialog.settings()
        try:
            self.export_layers(**settings)
        except Exception as exc:
            detail = traceback.format_exc()
            QMessageBox.critical(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                f"処理中に予期しないエラーが発生しました。\n\n{exc}\n\n{detail}",
            )

    def layer_panel_layers(self):
        """Return layers in layer panel order, traversing groups."""
        root = QgsProject.instance().layerTreeRoot()
        result = []
        seen_ids = set()

        def walk(node):
            for child in node.children():
                if QgsLayerTreeLayer is not None and isinstance(child, QgsLayerTreeLayer):
                    layer = child.layer()
                    if layer is not None and layer.id() not in seen_ids:
                        result.append(layer)
                        seen_ids.add(layer.id())
                elif hasattr(child, "children"):
                    walk(child)

        walk(root)
        return result

    def build_entries(self, layers, save_vectors=True, save_rasters=True):
        entries = []
        skipped = []

        for layer in layers:
            if not layer or not layer.isValid():
                name = layer.name() if layer else "不明なレイヤ"
                skipped.append(f"SKIP: {name} / 無効なレイヤ")
                continue

            if layer.type() == QgsMapLayer.VectorLayer:
                if not save_vectors:
                    continue
                kind = "vector"
            elif layer.type() == QgsMapLayer.RasterLayer:
                if not save_rasters:
                    continue
                if not is_gdal_raster_layer(layer):
                    skipped.append(
                        f"SKIP: {layer.name()} / ラスタですが provider={layer.providerType()} のためスキップ"
                    )
                    continue
                kind = "raster"
            else:
                skipped.append(f"SKIP: {layer.name()} / 対象外レイヤ種別")
                continue

            suffix = crs_suffix(layer)
            base_name = sanitize_output_name(layer.name(), "layer")
            target_name = f"{base_name}_{suffix}"
            crs_label = ""
            try:
                crs_label = layer.crs().authid() if layer.crs() and layer.crs().isValid() else "CRS未設定"
            except Exception:
                crs_label = "CRS未設定"

            entries.append(
                {
                    "layer": layer,
                    "kind": kind,
                    "source_name": layer.name(),
                    "target_name": target_name,
                    "crs_label": crs_label,
                    "auto_renamed": False,
                }
            )

        duplicates_found = self.apply_auto_suffix_for_duplicates(entries)
        return entries, skipped, duplicates_found

    def apply_auto_suffix_for_duplicates(self, entries):
        counts = {}
        duplicates_found = False
        for entry in entries:
            base = entry["target_name"]
            key = (entry["kind"], base.casefold())
            if key not in counts:
                counts[key] = 1
                continue
            duplicates_found = True
            counts[key] += 1
            new_name = f"{base}_{counts[key]}"
            while (entry["kind"], new_name.casefold()) in counts:
                counts[key] += 1
                new_name = f"{base}_{counts[key]}"
            entry["target_name"] = new_name
            entry["auto_renamed"] = True
            counts[(entry["kind"], new_name.casefold())] = 1
        return duplicates_found

    def export_layers(self, gpkg_path, save_vectors, save_vector_styles, save_rasters, save_raster_styles, save_project=False):
        layers = self.layer_panel_layers()
        if not layers:
            QMessageBox.information(self.iface.mainWindow(), PLUGIN_NAME, "レイヤパネルにレイヤがありません。")
            return

        entries, skipped, duplicates_found = self.build_entries(layers, save_vectors, save_rasters)
        if not entries:
            LogDialog(PLUGIN_NAME, "保存対象レイヤがありません。\n\n" + "\n".join(skipped), self.iface.mainWindow()).exec_()
            return

        if duplicates_found:
            name_dialog = NameEditDialog(entries, self.iface.mainWindow())
            if name_dialog.exec_() != QDialog.Accepted:
                return

        vector_entries = [e for e in entries if e["kind"] == "vector"]
        raster_entries = [e for e in entries if e["kind"] == "raster"]
        temporary_layers = [
            layer for layer in layers
            if is_vector_layer(layer) and (layer.providerType() or "").lower() == "memory"
        ]
        project_path = os.path.splitext(gpkg_path)[0] + ".qgz"
        current_project_path = QgsProject.instance().fileName()

        # Check all potentially destructive decisions BEFORE exporting any data.
        if save_project:
            if current_project_path and os.path.normcase(os.path.abspath(current_project_path)) == os.path.normcase(os.path.abspath(project_path)):
                QMessageBox.warning(
                    self.iface.mainWindow(), PLUGIN_NAME,
                    "新規プロジェクトの保存先が現在開いているプロジェクトと同じです。\n"
                    "元のプロジェクトを保護するため、別のGeoPackage名を指定してください。",
                )
                return
            if os.path.exists(project_path) and QMessageBox.question(
                self.iface.mainWindow(), PLUGIN_NAME,
                f"新規QGISプロジェクトは既に存在します。\n\n{project_path}\n\n上書きしてよろしいですか？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            ) != QMessageBox.Yes:
                return

        if vector_entries and os.path.exists(gpkg_path):
            ret = QMessageBox.question(
                self.iface.mainWindow(), PLUGIN_NAME,
                "指定されたGeoPackageは既に存在します。\n\n上書きしてよろしいですか？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            )
            if ret != QMessageBox.Yes:
                return
            try:
                os.remove(gpkg_path)
            except Exception as exc:
                QMessageBox.critical(
                    self.iface.mainWindow(), PLUGIN_NAME,
                    f"既存GeoPackageを削除できませんでした。\nファイルをQGISや他のアプリで開いていないか確認してください。\n\n{exc}",
                )
                return

        log = [f"出力先GeoPackage: {gpkg_path}", ""]
        vector_ok = 0
        vector_style_ok = 0
        raster_ok = 0
        raster_style_ok = 0
        error_count = 0
        exported_sources = {}
        failed_vectors = []
        failed_rasters = []
        raster_dir = ""
        temporary_ok = 0
        project_ok = False
        project_error = ""
        total_steps = (
            len(vector_entries) * (1 + bool(save_vector_styles))
            + len(raster_entries) * (1 + bool(save_raster_styles))
            + len(temporary_layers)
            + int(save_project)
        )
        progress = ExportProgressDialog(total_steps, self.iface.mainWindow())
        try:
            if vector_entries:
                log.append("[ベクタ保存]")
                for index, entry in enumerate(vector_entries):
                    layer = entry["layer"]
                    target_name = entry["target_name"]
                    vector_saved = False
                    progress.start("ベクタレイヤの書き出し", layer.name())
                    try:
                        options = QgsVectorFileWriter.SaveVectorOptions()
                        options.driverName = "GPKG"
                        options.fileEncoding = "UTF-8"
                        options.layerName = target_name
                        original_fid_output = prepare_gpkg_fid_attributes(layer, options)
                        expected_count = layer.featureCount()
                        options.actionOnExistingFile = (
                            QgsVectorFileWriter.CreateOrOverwriteFile
                            if index == 0 or not os.path.exists(gpkg_path)
                            else QgsVectorFileWriter.CreateOrOverwriteLayer
                        )
                        feedback = QgsFeedback()
                        feedback.progressChanged.connect(progress.update_percent)
                        options.feedback = feedback
                        result = QgsVectorFileWriter.writeAsVectorFormatV3(
                            layer, gpkg_path, QgsProject.instance().transformContext(), options
                        )
                        err, msg = vector_writer_error_message(result)
                        if is_no_error(err):
                            valid, detail = verify_vector_output(
                                layer, gpkg_path, target_name, expected_count, original_fid_output
                            )
                            if valid:
                                vector_saved = True
                                vector_ok += 1
                                exported_sources[layer.id()] = ("ogr", f"{gpkg_path}|layername={target_name}")
                                log.append(f"OK: {layer.name()} -> {target_name} / {expected_count} 件")
                                if original_fid_output:
                                    log.append(f"FID: 元のfid属性を {original_fid_output} に保持し、出力fidを新規採番")
                            else:
                                error_count += 1
                                failed_vectors.append(layer.name())
                                log.append(f"ERROR: {layer.name()} -> {target_name} / 保存検証エラー: {detail}")
                                log.append("注意: この出力レイヤは不完全な可能性があるため使用しないでください")
                        else:
                            error_count += 1
                            failed_vectors.append(layer.name())
                            log.append(f"ERROR: {layer.name()} -> {target_name} / {msg or err}")
                            log.append("注意: この出力レイヤは不完全な可能性があるため使用しないでください")
                    except Exception as exc:
                        error_count += 1
                        failed_vectors.append(layer.name())
                        log.append(f"ERROR: {layer.name()} -> {target_name} / {exc}")
                    finally:
                        progress.finish()

                    if save_vector_styles:
                        progress.start("ベクタスタイルの保存", layer.name())
                        try:
                            if vector_saved:
                                if self.save_vector_style_to_gpkg(layer, gpkg_path, target_name, log):
                                    vector_style_ok += 1
                                else:
                                    error_count += 1
                            else:
                                log.append(f"STYLE SKIP: {target_name} / ベクタ保存失敗のため未実行")
                        except Exception as exc:
                            error_count += 1
                            log.append(f"STYLE ERROR: {target_name} / {exc}")
                        finally:
                            progress.finish()
                log.append("")
            else:
                log.extend(["[ベクタ保存] 対象なし", ""])

            if raster_entries:
                gpkg_dir = os.path.dirname(gpkg_path)
                gpkg_base = os.path.splitext(os.path.basename(gpkg_path))[0]
                try:
                    raster_dir = make_unique_directory(os.path.join(gpkg_dir, f"{gpkg_base}_raster"))
                    log.append(f"[ラスタ保存] 保存先フォルダ: {raster_dir}")
                except Exception as exc:
                    raster_dir = ""
                    log.append(f"[ラスタ保存] ERROR: 出力フォルダを作成できません: {exc}")
                for entry in raster_entries:
                    layer = entry["layer"]
                    target_name = entry["target_name"]
                    tif_path = os.path.join(raster_dir, f"{target_name}.tif") if raster_dir else ""
                    raster_saved = False
                    progress.start("ラスタレイヤの書き出し", layer.name())
                    try:
                        if raster_dir and self.export_raster_to_geotiff(layer, tif_path, progress.update_percent):
                            raster_saved = True
                            raster_ok += 1
                            log.append(f"OK: {layer.name()} -> {os.path.basename(tif_path)}")
                            exported_sources[layer.id()] = ("gdal", tif_path)
                        else:
                            error_count += 1
                            failed_rasters.append(layer.name())
                            log.append(f"ERROR: {layer.name()} -> {target_name}.tif / ラスタ書き出し失敗")
                    except Exception as exc:
                        error_count += 1
                        failed_rasters.append(layer.name())
                        log.append(f"ERROR: {layer.name()} -> {target_name}.tif / {exc}")
                    finally:
                        progress.finish()

                    if save_raster_styles:
                        progress.start("ラスタスタイルの保存", layer.name())
                        try:
                            if raster_saved:
                                qml_path = os.path.join(raster_dir, f"{target_name}.qml")
                                if self.save_qml_style(layer, qml_path, log):
                                    raster_style_ok += 1
                                else:
                                    error_count += 1
                            else:
                                log.append(f"STYLE SKIP: {target_name} / ラスタ保存失敗のため未実行")
                        except Exception as exc:
                            error_count += 1
                            log.append(f"STYLE ERROR: {target_name} / {exc}")
                        finally:
                            progress.finish()
                log.append("")
            else:
                log.extend(["[ラスタ保存] 対象なし", ""])

            # Successfully written memory layers become real GPKG layers in the
            # open project, as requested in v0.1.2. Other disk-based layers
            # are NOT modified; only the new .qgz uses remapped sources.
            if temporary_layers:
                log.append("[一時レイヤの保存済みレイヤへの切り替え]")
                for layer in temporary_layers:
                    progress.start("一時レイヤの切り替え", layer.name())
                    try:
                        exported = exported_sources.get(layer.id())
                        if exported is None:
                            log.append(f"SKIP: {layer.name()} / GeoPackageに正常保存されていないため一時レイヤのまま保持")
                        elif layer.isEditable():
                            log.append(f"SKIP: {layer.name()} / 編集モード中のため一時レイヤのまま保持（編集を確定してから再実行してください）")
                        elif self.rebind_temporary_layer(layer, exported[1]):
                            temporary_ok += 1
                            log.append(f"OK: {layer.name()} / 一時レイヤを解除しました")
                        else:
                            error_count += 1
                            log.append(f"ERROR: {layer.name()} / 保存済みレイヤへの切り替えを確認できませんでした")
                    except Exception as exc:
                        error_count += 1
                        log.append(f"ERROR: {layer.name()} / 一時レイヤ切り替え失敗: {exc}")
                    finally:
                        progress.finish()
                log.append("")

            if save_project:
                progress.start("新規QGISプロジェクトの保存", os.path.basename(project_path))
                log.append("[QGISプロジェクトの新規保存]")
                try:
                    remaining_memory = [
                        layer.name() for layer in temporary_layers
                        if not layer.isValid() or (layer.providerType() or "").lower() == "memory"
                    ]
                    # Never silently create a new project that still depends on
                    # old local data for eligible vector/GDAL raster layers.
                    missing_local_layers = [
                        layer.name() for layer in QgsProject.instance().mapLayers().values()
                        if (is_vector_layer(layer) or is_gdal_raster_layer(layer))
                        and layer.id() not in exported_sources
                    ]
                    if failed_vectors or failed_rasters:
                        project_error = "一部レイヤの書き出しが失敗したため、新規プロジェクトを作成しませんでした: " + "、".join((failed_vectors + failed_rasters)[:8])
                    elif remaining_memory:
                        project_error = "一時レイヤが残っているため、新規プロジェクトを作成しませんでした: " + "、".join(remaining_memory[:8])
                    elif missing_local_layers:
                        project_error = "元データへの参照が残るため、新規プロジェクトを作成しませんでした（ベクタ・ラスタの保存設定をご確認ください）: " + "、".join(missing_local_layers[:8])
                    else:
                        project_ok, project_error = self.write_new_project(project_path, exported_sources)
                    if project_ok:
                        log.append(f"OK: 新規QGISプロジェクト -> {project_path}")
                        log.append(f"参照先: ベクタ {vector_ok}件をGeoPackage、ラスタ {raster_ok}件をGeoTIFFに変更")
                        log.append("注: WMSなどのオンラインレイヤは引き続き外部サービスを参照します")
                    else:
                        error_count += 1
                        log.append(f"ERROR: 新規QGISプロジェクト保存失敗: {project_error or '原因不明'}")
                except Exception as exc:
                    error_count += 1
                    project_error = str(exc)
                    log.append(f"ERROR: 新規QGISプロジェクト保存失敗: {project_error}")
                finally:
                    progress.finish()
                log.append("")
        finally:
            progress.close()

        if skipped:
            log.append("[スキップ]")
            log.extend(skipped)
            log.append("")

        log.extend([
            "[結果]",
            f"ベクタ保存成功: {vector_ok} 件",
            f"ベクタスタイル保存成功: {vector_style_ok} 件",
            f"ラスタ保存成功: {raster_ok} 件",
            f"ラスタスタイル保存成功: {raster_style_ok} 件",
            f"一時レイヤ解除成功: {temporary_ok} 件",
        ])
        if save_project:
            log.append(f"新規QGISプロジェクト: {'成功' if project_ok else '未作成'}")
        log.extend([f"スキップ: {len(skipped)} 件", f"エラー: {error_count} 件"])
        if raster_dir:
            log.append(f"ラスタ保存フォルダ: {raster_dir}")

        # Include the reason in both the QGIS notification and detail log.
        if error_count == 0 and (not save_project or project_ok):
            status_text = "保存が正常に完了しました。"
            status_type = "success"
        elif vector_ok + raster_ok:
            status_text = f"一部未完了（エラー{error_count}件）。" + (f" 新規プロジェクト: {project_error[:90]}" if project_error else " 結果画面をご確認ください。")
            status_type = "warning"
        else:
            status_text = f"保存に失敗しました（エラー{error_count}件）。結果画面をご確認ください。"
            status_type = "critical"

        LogDialog(PLUGIN_NAME, "\n".join(log), self.iface.mainWindow()).exec_()
        if status_type == "success":
            self.iface.messageBar().pushSuccess(PLUGIN_NAME, status_text)
        elif status_type == "warning":
            self.iface.messageBar().pushWarning(PLUGIN_NAME, status_text)
        else:
            self.iface.messageBar().pushCritical(PLUGIN_NAME, status_text)

    def rebind_temporary_layer(self, layer, gpkg_uri):
        """Point a successfully exported memory layer at its persisted GPKG table.

        Keeps the same QGIS layer object/ID, layer tree location, visibility and
        name. The original memory provider is replaced only after validation.
        """
        if (layer.providerType() or "").lower() != "memory":
            return False
        exported = QgsVectorLayer(gpkg_uri, layer.name(), "ogr")
        if not exported.isValid() or exported.geometryType() != layer.geometryType():
            return False

        original_name = layer.name()
        original_style = QgsMapLayerStyle()
        original_style.readFromLayer(layer)
        layer.setDataSource(gpkg_uri, original_name, "ogr", False)
        if not layer.isValid() or (layer.providerType() or "").lower() != "ogr":
            # This unexpected case is reported, not hidden by toggling an icon.
            return False
        if original_style.isValid():
            original_style.writeToLayer(layer)
        layer.setName(original_name)
        layer.triggerRepaint()
        QgsProject.instance().setDirty(True)
        return True

    @staticmethod
    def project_relative_source(project_path, provider, source):
        """Return a portable relative URI for exported GeoPackage/GeoTIFF."""
        base_dir = os.path.dirname(os.path.abspath(project_path))
        if provider == "ogr":
            path, separator, suffix = source.partition("|")
        else:
            path, separator, suffix = source, "", ""
        relative = os.path.relpath(os.path.abspath(path), base_dir).replace("\\", "/")
        if not relative.startswith("."):
            relative = "./" + relative
        return relative + (separator + suffix if separator else "")

    def write_new_project(self, project_path, exported_sources):
        """Safely create a NEW .qgz with remapped local sources.

        QGIS first writes a temporary .qgz in the same output directory. We
        then patch the *finished* serialized project and verify every remapped
        URI. The original QgsProject filename/dirty flag are restored and the
        user-selected project is replaced atomically only after validation.
        """
        project = QgsProject.instance()
        previous_name = project.fileName()
        was_dirty = project.isDirty()
        parent_dir = os.path.dirname(os.path.abspath(project_path))
        expected = {
            layer_id: (provider, self.project_relative_source(project_path, provider, source))
            for layer_id, (provider, source) in exported_sources.items()
        }
        raw_path = ""
        patched_path = ""
        try:
            fd, raw_path = tempfile.mkstemp(prefix=".lp2gp_qgs_", suffix=".qgz", dir=parent_dir)
            os.close(fd)
            os.unlink(raw_path)  # QgsProject.write must create the archive itself.
            try:
                try:
                    success = bool(project.write(raw_path))
                except Exception as exc:
                    raise ProjectSaveError(f"QGISによるプロジェクト書き出し中に例外が発生: {exc}") from exc
            finally:
                # Restore the open project even on partial QGIS writer failure.
                project.setFileName(previous_name)
                project.setDirty(was_dirty)
            if not success:
                details = ""
                try:
                    details = str(project.error() or "")
                except Exception:
                    pass
                raise ProjectSaveError("QGISがプロジェクト書き出しに失敗しました" + (f": {details}" if details else "（書き込み先のアクセス権・容量をご確認ください）"))
            if not os.path.isfile(raw_path):
                raise ProjectSaveError("QGISは書き出し成功を返しましたが、.qgzファイルが作成されていません")
            try:
                with zipfile.ZipFile(raw_path, "r") as archive:
                    if archive.testzip() is not None:
                        raise ProjectSaveError("QGISが生成した.qgzに破損が見つかりました")
                    qgs_names = [name for name in archive.namelist() if name.lower().endswith(".qgs")]
                    if len(qgs_names) != 1:
                        raise ProjectSaveError(f".qgz内のQGISプロジェクトXMLが1件ではありません（{len(qgs_names)}件）")
                    new_xml, replaced = rewrite_qgs_xml(archive.read(qgs_names[0]), expected)
                    # Ensure that both source refs and tree refs are consistent.
                    check_qgs_xml_sources(new_xml, expected)
                    project_stem = os.path.splitext(os.path.basename(project_path))[0]
                    original_stem = os.path.splitext(os.path.basename(raw_path))[0]
                    fd, patched_path = tempfile.mkstemp(prefix=".lp2gp_ready_", suffix=".qgz", dir=parent_dir)
                    os.close(fd)
                    with zipfile.ZipFile(patched_path, "w") as out_archive:
                        for member in archive.infolist():
                            info = copy.copy(member)
                            content = new_xml if member.filename == qgs_names[0] else archive.read(member)
                            # Match the internal project name to the final .qgz name.
                            folder, basename = os.path.split(info.filename)
                            if member.filename == qgs_names[0]:
                                info.filename = os.path.join(folder, project_stem + ".qgs").replace("\\", "/")
                            elif basename == original_stem + ".qgd":
                                info.filename = os.path.join(folder, project_stem + ".qgd").replace("\\", "/")
                            out_archive.writestr(info, content)
            except (OSError, zipfile.BadZipFile) as exc:
                raise ProjectSaveError(f".qgzの読み書き中に失敗しました: {exc}") from exc

            try:
                with zipfile.ZipFile(patched_path, "r") as archive:
                    invalid = archive.testzip()
                    if invalid is not None:
                        raise ProjectSaveError(f"出力アーカイブのZIP検証に失敗しました: {invalid}")
                    qgs_name = os.path.splitext(os.path.basename(project_path))[0] + ".qgs"
                    if qgs_name not in archive.namelist():
                        raise ProjectSaveError(f"完成アーカイブ内に {qgs_name} がありません")
                    check_qgs_xml_sources(archive.read(qgs_name), expected)
            except (OSError, zipfile.BadZipFile) as exc:
                raise ProjectSaveError(f"完成した.qgzを検証できません: {exc}") from exc

            try:
                os.replace(patched_path, project_path)
                patched_path = ""
            except OSError as exc:
                raise ProjectSaveError(f"検証済み.qgzを保存先に配置できません（権限・ファイル使用中を確認）: {exc}") from exc
            return True, f"出力済み{len(replaced)}レイヤのデータソースを検証済み"
        except ProjectSaveError as exc:
            return False, str(exc)
        except Exception as exc:
            return False, f"新規プロジェクト保存中の予期しないエラー: {exc}"
        finally:
            for path in (raw_path, patched_path):
                if path and os.path.isfile(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

    def save_vector_style_to_gpkg(self, source_layer, gpkg_path, target_name, log):
        """Copy source style to exported GPKG layer and save it into the database."""
        tmp_qml = ""
        try:
            fd, tmp_qml = tempfile.mkstemp(suffix=".qml")
            os.close(fd)
            self.save_qml_style(source_layer, tmp_qml, log=None)

            uri = f"{gpkg_path}|layername={target_name}"
            exported = QgsVectorLayer(uri, target_name, "ogr")
            if not exported.isValid():
                log.append(f"STYLE ERROR: {target_name} / 出力レイヤを再読込できませんでした")
                return False
            exported.loadNamedStyle(tmp_qml)
            try:
                exported.saveStyleToDatabase("default", f"Copied from {source_layer.name()}", True, "")
                log.append(f"STYLE OK: {target_name} / GeoPackage内に保存")
                return True
            except Exception as exc:
                log.append(f"STYLE ERROR: {target_name} / GeoPackage内スタイル保存失敗: {exc}")
                return False
        except Exception as exc:
            log.append(f"STYLE ERROR: {target_name} / {exc}")
            return False
        finally:
            if tmp_qml and os.path.exists(tmp_qml):
                try:
                    os.remove(tmp_qml)
                except Exception:
                    pass

    def save_qml_style(self, layer, qml_path, log=None):
        try:
            result = layer.saveNamedStyle(qml_path)
            ok = True
            if isinstance(result, tuple):
                # QGIS commonly returns (message, success) or similar depending on version.
                bools = [v for v in result if isinstance(v, bool)]
                if bools:
                    ok = bools[-1]
            if log is not None:
                if ok:
                    log.append(f"STYLE OK: {layer.name()} -> {os.path.basename(qml_path)}")
                else:
                    log.append(f"STYLE ERROR: {layer.name()} -> {os.path.basename(qml_path)}")
            return ok
        except Exception as exc:
            if log is not None:
                log.append(f"STYLE ERROR: {layer.name()} -> {os.path.basename(qml_path)} / {exc}")
            return False

    def export_raster_to_geotiff(self, layer, output_path, progress_callback=None):
        pipe = QgsRasterPipe()
        provider = layer.dataProvider()
        if provider is None:
            return False
        if not pipe.set(provider.clone()):
            return False

        writer = QgsRasterFileWriter(output_path)
        writer.setOutputFormat("GTiff")
        feedback = QgsRasterBlockFeedback()
        if progress_callback is not None:
            feedback.progressChanged.connect(progress_callback)
        result = writer.writeRaster(
            pipe,
            layer.width(),
            layer.height(),
            layer.extent(),
            layer.crs(),
            QgsProject.instance().transformContext(),
            feedback,
        )
        try:
            return int(result) == int(QgsRasterFileWriter.NoError)
        except Exception:
            return result == QgsRasterFileWriter.NoError
