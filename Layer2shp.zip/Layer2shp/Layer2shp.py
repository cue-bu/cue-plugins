# -*- coding: utf-8 -*-

import os
import collections

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtXml import *
from qgis.core import *

from qgis.gui import (QgsAttributeTableModel,
                      QgsAttributeTableView,
                      QgsAttributeTableFilterModel)


class SimpleSaveTemporarylayer(object):

    def __init__(self, iface):

        self.iface = iface
        self.menu_name = "拡張機能"
        self.plugin_name = "レイヤを一括shp化"
        self.icon = QIcon(os.path.dirname(__file__) + "/icons/re_loop_save_shp.png")

    def initGui(self):

        self.action = QAction(
            self.icon, self.plugin_name, self.iface.mainWindow()
        )

        self.action.setWhatsThis(self.plugin_name)
        self.action.setStatusTip("{}します".format(self.plugin_name))
        self.action.triggered.connect(self.run)

        # self.addAction()
        self.addMenu()
        self.addCustumToolBar()

    def onClosePlugin(self):
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
        self.pluginIsActive = False

    # def addAction(self):
    #     self.iface.pluginMenu().addAction(self.action)
    #     self.iface.pluginToolBar().addAction(self.action)

    # def removeAction(self):
    #     self.iface.pluginMenu().removeAction(self.action)
    #     self.iface.pluginToolBar().removeAction(self.action)

    def addMenu(self):
        self.menubar = self.iface.mainWindow().menuBar()
        self.menu = self.iface.mainWindow().findChild(QMenu, self.menu_name)
        if self.menu is None:
            self.menu = QMenu(self.iface.mainWindow())
            self.menu.setObjectName(self.menu_name)
            self.menu.setTitle(self.menu_name)
            self.menubar.insertMenu(self.iface.firstRightStandardMenu().menuAction(),
                                     self.menu)
        self.menu.addAction(self.action)

    def removeMenu(self):
        self.menu.removeAction(self.action)
        if len(self.menu.actions()) == 0:
            self.menu.menuAction().setVisible(False)

    def addCustumToolBar(self):
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.menu_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(self.menu_name)
            self.toolbar.setObjectName(self.menu_name)
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

    def removeCustumToolBar(self):
        self.toolbar.removeAction(self.action)
        if len(self.toolbar.actions()) == 0:
            del self.toolbar

    def unload(self):
        # self.removeAction()
        self.removeMenu()
        self.removeCustumToolBar()

    def run(self):
        # layer_active = self.iface.activeLayer()
        # layers = QgsProject.instance().layerTreeRoot().findLayers()   # original code
        # layers = QgsProject.instance().mapLayers().values()   # レイヤパネルのレイヤを全て取得
        layers = QgsProject.instance().layerTreeRoot().checkedLayers()  # レイヤパネル内のチェックがついたレイヤを取得
        layers = [layer for layer in layers if isinstance(layer, QgsVectorLayer)]   # チェックがついたレイヤから、ベクタレイヤのみを抽出

        # filepath = QFileDialog.getSaveFileName(self.iface.mainWindow(),
        #                                     'レイヤをshp化',
        #                                     '/home/{}.shp'.format(layer_active.name()),
        #                                     filter='*.shp')
        # 実行ディレクトリ取得
        rootpath = os.path.abspath(os.path.dirname("__file__"))
        # ディレクトリ選択ダイアログを表示
        dirpath = QFileDialog.getExistingDirectory(None, "rootpath", rootpath)
        # キャンセル時の処理
        if not dirpath:
            QMessageBox.information(None, "中断", "フォルダ選択がキャンセルされました。")
            return  # ここで処理をストップさせる
        # del layers[layer_active.name()]
        

        # 指定フォルダ先のshpファイルのリスト（拡張子なし）
        dir_files = os.listdir(str(dirpath))
        shp_files = [i for i in dir_files if i.endswith(".shp") == True]
        files = [s[:-4] for s in shp_files]
            

        # レイヤパネルに同名のレイヤがあった際に、上から順に末尾に数字を割り振る
        # レイヤ名のみのリストを作成
        layer_names = []
        for layer in layers:
            layer_names.append(str(layer.name()))
        # 重複しているレイヤ名は末尾に_～をつける
        duplications = collections.Counter(layer_names).most_common()

        for num in range(len(duplications)):
            count = 0

            # 指定フォルダ先に同名ファイルが存在する場合(duplications[num][0]が含まれている場合)
            up = len([s for s in files if duplications[num][0] in s])
            if up != 0:
                index = [i for i, x in enumerate(layer_names) if x == duplications[num][0]]
                for idx in index:
                    name = layer_names[idx] + "_" + str(count + up)
                    layer_names[idx] = name
                    count += 1

            # 指定フォルダに同名ファイルはないが、レイヤパネルに複数存在している場合
            elif duplications[num][1] != 1:
                    index = [i for i, x in enumerate(layer_names) if x == duplications[num][0]]
                    for idx in index:
                        name = layer_names[idx] + "_" + str(count)
                        layer_names[idx] = name
                        count += 1

        layer_idx = 0
        for layer in layers:
            # ジオメトリを持たないレイヤに対しては処理を行わない（表データ等）
            if layer.geometryType() != 4:
                # filepath = QFileDialog.getSaveFileName(self.iface.mainWindow(),
                #                                     'レイヤをshp化',
                #                                     '/home/{}.shp'.format(layer.name()),
                #                                     filter='*.shp')

                # print(layer)
                # _file_path = str(filepath[0]).rsplit('/', 1)[0]
                file_path = str(dirpath) + '/' + str(layer_names[layer_idx]) + '.shp'

            
                self.save_layer_format(layer, file_path)

                # self.applyDataSource(layer, 'ogr', filepath[0])
                # self.applyDataSource(layer, 'ogr', file_path)
                self.iface.messageBar().pushMessage("Layer Saved", file_path)
                layer_idx += 1


    def save_layer_format(self, layer, filepath, format="Esri Shapefile"):
        none_ext_path = os.path.splitext(filepath)[0]

        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "ESRI Shapefile"
        save_options.fileEncoding = layer.dataProvider().encoding()

        if format == "Esri Shapefile":
            writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".shp", transform_context, save_options)
        # if format == "CSV":
        #     writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".csv", "System", layer.crs(), format, layerOptions=['GEOMETRY=AS_WKT'])
        # if format == "MapInfo File":
        #     writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".TAB", "System", layer.crs(), format)
        # if format == "GeoJSON":
        #     writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".GeoJSON", "System", layer.crs(), format)
        # if format == "PGDump":
        #     writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".sql", "System", layer.crs(), format)
        # if format == "GPKG":
        #     writer = QgsVectorFileWriter.writeAsVectorFormatV2(layer, none_ext_path + ".gpkg", "System", layer.crs(), format)

    def applyDataSource(self, applyLayer, newProvider, newDatasource):

        probeLayer = QgsVectorLayer(newDatasource, "probe", newProvider)
        extent = None

        if not probeLayer.isValid():
            self.iface.messageBar().pushMessage("Error", "New data source is not valid: "+newProvider+"|"+newDatasource, level=Qgis.Critical, duration=4)
            return None

        if applyLayer.type() == QgsMapLayer.VectorLayer and probeLayer.geometryType() != applyLayer.geometryType():
            self.iface.messageBar().pushMessage("Error", "Geometry type mismatch", level=Qgis.Critical, duration=4)
            return None

        newDatasource = probeLayer.source()
        # self.setDataSource(applyLayer, newProvider, newDatasource, extent)

    def setDataSource(self, layer, newProvider, newDatasource, extent=None):

        XMLDocument = QDomDocument("style")
        XMLMapLayers = XMLDocument.createElement("maplayers")
        XMLMapLayer = XMLDocument.createElement("maplayer")
        context = QgsReadWriteContext()
        layer.writeLayerXml(XMLMapLayer, XMLDocument, context)

        XMLMapLayer.firstChildElement("datasource").firstChild().setNodeValue(newDatasource)
        XMLMapLayer.firstChildElement("provider").firstChild().setNodeValue(newProvider)
        if extent:
            XMLMapLayerExtent = XMLMapLayer.firstChildElement("extent")
            XMLMapLayerExtent.firstChildElement("xmin").firstChild().setNodeValue(str(extent.xMinimum()))
            XMLMapLayerExtent.firstChildElement("xmax").firstChild().setNodeValue(str(extent.xMaximum()))
            XMLMapLayerExtent.firstChildElement("ymin").firstChild().setNodeValue(str(extent.yMinimum()))
            XMLMapLayerExtent.firstChildElement("ymax").firstChild().setNodeValue(str(extent.yMaximum()))

        XMLMapLayers.appendChild(XMLMapLayer)
        XMLDocument.appendChild(XMLMapLayers)
        layer.readLayerXml(XMLMapLayer, context)
        layer.dataProvider().setEncoding(u'System')
        layer.reload()

        self.iface.actionDraw().trigger()
        self.iface.mapCanvas().refresh()
        self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        self.iface.messageBar().pushMessage("Layer Saved", newDatasource)
